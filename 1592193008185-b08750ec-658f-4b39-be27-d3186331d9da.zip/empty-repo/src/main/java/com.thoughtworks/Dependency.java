package com.thoughtworks;

public class Dependency {
    public String say(){
        return "Leave me alone.";
    }
}
